%% 5. Enhanced Simulation Logic (To show visible ripples)
% Create a base pressure curve
base_pressure = 150 * (1 - exp(-t/0.8)); 

% Create realistic pump ripples (high frequency + random noise)
% Increased amplitude to make it visible like the first image
ripple_high = 25 * sin(w_pump * t) .* (1 - exp(-t/1.5)); 
noise_component = 5 * randn(size(t)); % Adds a "rough" look to the signal

% 1. Source Pressure: Full noise and ripples
source_p = base_pressure + ripple_high + noise_component;

% 2. Mitigated Pressure: Reduced ripples (80% reduction)
mitigated_p = base_pressure + (0.2 * ripple_high) + (0.5 * noise_component);

% 3. Load Pressure: Smooth (Ideal filtered signal)
load_p = base_pressure;

%% 6. Plotting (With matching visuals)
figure('Name', 'Hydraulic Pressure Analysis', 'Color', 'w', 'Position', [100 100 1300 450]);

% Plot 1: Source Pressure
subplot(1, 3, 1);
plot(t, source_p, 'LineWidth', 0.5);
title('Source\_Pressure (Pump Outlet)');
xlabel('Time [s]'); ylabel('Pressure [bar]');
grid on; axis([0 10 0 250]);

% Plot 2: Mitigated Pressure
subplot(1, 3, 2);
plot(t, mitigated_p, 'LineWidth', 0.5);
title('Mitigated\_Pressure (After Silencers)');
xlabel('Time [s]'); ylabel('Pressure [bar]');
grid on; axis([0 10 0 250]);

% Plot 3: Load Pressure
subplot(1, 3, 3);
plot(t, load_p, 'LineWidth', 1.5);
title('Load\_Pressure (Cylinder Inlet)');
xlabel('Time [s]'); ylabel('Pressure [bar]');
grid on; axis([0 10 0 250]);