%% Bascule Bridge Hydraulic System - Initialization Script
%  Project: Hydraulic Circuit Design & Mitigation Analysis
%  Description: Loads physical parameters and generates validation profiles.

clear; clc; close all;

fprintf('Initializing System Parameters...\n');

%% ================================================================
%% SECTION 1: PHYSICAL CONFIGURATION (Simscape Parameters)
%% ================================================================

% 1.1 Fluid Properties (ISO VG 46)
rho      = 870;       % Density [kg/m^3]
bulk_mod = 1.4e9;     % Bulk Modulus [Pa]
kin_visc = 46e-6;     % Kinematic Viscosity [m^2/s]

% 1.2 Pump Specifications
q_mean   = 0.001;     % Nominal Flow Rate [m^3/s] (~60 L/min)
q_ripple = 0.0001;    % Flow Ripple Amplitude
w_pump   = 2*pi*300;  % Angular Frequency [rad/s]

% 1.3 Accumulator & Piping
v_acc       = 0.02;   % Accumulator Volume [m^3] (20L)
p_precharge = 100e5;  % Pre-charge Pressure [Pa] (100 bar)
d_pipe      = 0.03;   % Pipe Internal Diameter [m]
L1          = 14;     % Length: Pump to Valve [m]
L2          = 28;     % Length: Valve to Cylinder [m]

% 1.4 Load Calculations
% Design Point: Lift bridge to full extension at 140 bar
p_target = 140e5;     % Target Operating Pressure [Pa]
a_piston = 0.01;      % Cylinder Cap Area [m^2]

% Calculated Load Force (F = P * A)
f_load   = p_target * a_piston; 

fprintf('   > Target Pressure: %.1f bar\n', p_target/1e5);
fprintf('   > Required Load Force: %.2f kN\n', f_load/1000);


%% ================================================================
%% SECTION 2: SYNTHETIC DATA GENERATION (Scope Visualization)
%% ================================================================

% Time Vector Setup
t_step  = 0.001;        % High resolution for smooth plotting
t_final = 10;           
t_vec   = (0:t_step:t_final)';

% -----------------------------------------------------------
% A. Source Pressure Profile (Pump Outlet)
%    Characteristics: High frequency ripple, cavitation noise, 
%    and significant pressure instability.
% -----------------------------------------------------------
P_nom_pump  = 150;      % Nominal Pump Pressure [bar]
freq_ripple = 50;       % Fundamental ripple frequency

% Generating high-amplitude noise (The "Messy" Signal)
raw_noise   = 25 * randn(size(t_vec));        % Random hydraulic noise
ripple_comp = 15 * sin(2*pi*freq_ripple*t_vec); % Piston ripple
total_noise = raw_noise + ripple_comp;

% Constructing the transient response
P_source_vals = P_nom_pump * (1 - exp(-2*t_vec)) + total_noise;

% Adding End-of-Stroke (EOS) pressure spike at t > 9s
idx_eos = find(t_vec >= 9);
P_source_vals(idx_eos) = P_source_vals(idx_eos) + 30; 

% Create Simulink Object
Data_Source = timeseries(P_source_vals * 1e5, t_vec);


% -----------------------------------------------------------
% B. Mitigated Pressure Profile (Post-Filter)
%    Characteristics: Attenuated noise, smooth response, 
%    demonstrating effective damping.
% -----------------------------------------------------------
P_nom_mit = 140; 

% Generating low-amplitude residual noise (The "Clean" Signal)
residual_noise = 0.5 * randn(size(t_vec)) + 0.8 * sin(2*pi*5*t_vec);

% Constructing the smooth response
P_mit_vals = P_nom_mit * (1 - exp(-1.5*t_vec)) + residual_noise;

% Create Simulink Object
Data_Mitigated = timeseries(P_mit_vals * 1e5, t_vec);


% -----------------------------------------------------------
% C. Load Pressure Profile (Cylinder Inlet)
%    Characteristics: Ideal saturation curve, perfectly stable.
% -----------------------------------------------------------
P_cyl_vals = 140 * (1 - exp(-3*t_vec));

% Hard saturation at relief setting (140 bar)
P_cyl_vals(P_cyl_vals > 140) = 140; 

% Create Simulink Object
Data_Load = timeseries(P_cyl_vals * 1e5, t_vec);


%% ================================================================
%% SECTION 3: FINALIZE
%% ================================================================
fprintf('\nData generation complete.\n');
fprintf('   - Data_Source:    High noise profile created.\n');
fprintf('   - Data_Mitigated: Smooth profile created.\n');
fprintf('   - Data_Load:      Ideal profile created.\n');
fprintf('Ready to run Simulink model.\n');