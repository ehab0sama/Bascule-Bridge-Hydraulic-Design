% ========================================================================
% Setup Script for Bascule Bridge Hydraulic Model
% ========================================================================
% This script defines the physical parameters for the 'mitigation' 
% Simulink model and runs the simulation.
% ========================================================================

clear; close all; clc;

fprintf('--- Initializing Bridge Model Parameters ---\n');

%% 1. Simulation Settings
t_end = 10;            % Total simulation time [s]

%% 2. Fluid Properties (ISO VG 46 Oil)
rho = 870;             % Density [kg/m^3]
bulk_mod = 1.4e9;      % Bulk Modulus [Pa]
kin_visc = 46e-6;      % Kinematic Viscosity [m^2/s]

%% 3. Pump & Ripple Parameters
% Flow rate to lift the bridge
q_mean = 0.001;        % Mean flow rate [m^3/s] (~60 L/min)

% Ripple settings (10% noise)
q_ripple = 0.1 * q_mean; 
f_pump = 300;          % Pump frequency [Hz] (9 pistons @ 2000 RPM)
w_pump = 2*pi*f_pump;  % Angular frequency [rad/s]

%% 4. Pipe Dimensions
d_pipe = 0.03;         % Pipe ID [m] (30mm)
L1 = 14;               % Pipe 1: Pump to Valve [m]
L2 = 28;               % Pipe 2: Valve to Cylinder [m]

%% 5. Accumulator Data
v_acc = 0.02;          % Total volume [m^3] (20L)
p_precharge = 100e5;   % Gas precharge pressure [Pa] (100 bar)
% Note: Precharge must be lower than operating pressure (~140 bar)

%% 6. Cylinder & Load Calculation
% Cylinder dimensions
a_piston = 0.01;       % Cap end area [m^2]
a_rod = 0.005;         % Rod end area [m^2]

% Bridge load calculation
% Target operating pressure is 140 bar
p_target = 140e5;      

% Load Force (F = P * A)
f_load = p_target * a_piston; % Bridge weight equivalent [N]

fprintf('Calculation Results:\n');
fprintf('  Target Pressure: %d bar\n', p_target/1e5);
fprintf('  Required Load (for PS Constant): %.2f kN\n', f_load/1000);
disp('-------------------------------------------');

%% 7. Run Simulation

model_name = 'mitigation';

% Check if model file exists
if ~exist(model_name, 'file')
    error('Model file "%s" not found in the current directory.', model_name);
else
    fprintf('Loading and running: %s...\n', model_name);
    
    load_system(model_name);
    
    try
        % Run simulation with specified stop time
        sim_data = sim(model_name, 'StopTime', num2str(t_end));
        
        disp('Done!');
        disp('Check the Scopes in the model to see the results.');
        disp('-------------------------------------------');
    catch err
        % Error handling
        warning('Simulation failed to run.');
        disp(err.message);
        disp('Check your block connections and sensor references.');
    end
end